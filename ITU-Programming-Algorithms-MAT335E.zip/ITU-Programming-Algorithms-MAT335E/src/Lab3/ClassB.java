package mat335Labs.Lab3;

public class ClassB {

	public static void main(String[] args) {
		
		System.out.println("----------------True----------------");
		
		System.out.println(ClassA.hasMidpoint(1,2,1));

	}

}
