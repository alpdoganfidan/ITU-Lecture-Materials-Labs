// Name, Surname: Alp Doğan Fidan
// Student ID: 090180320
// Question no: 1

package Midterm_Exam;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c1 = new Customer(34, "Alp", "Çekmeköy", "553");
		
	}

}
