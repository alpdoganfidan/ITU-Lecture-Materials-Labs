package mat335Labs.Lab1;

import java.util.Scanner;

public class Lesson2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		//double c = (float) (a+b)/2;
		double c = (a+b)/2;
		System.out.println("result is " + c);
	}

}
