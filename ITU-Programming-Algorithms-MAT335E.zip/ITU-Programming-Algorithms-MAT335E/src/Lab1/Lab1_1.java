package mat335Labs.Lab1;

public class Lab1_1 {
	
	public static void main(String[] args) {
		
		System.out.println("This statement is written to first row.");
		System.out.println("This statement is written to second row.");
		System.out.print("This statement is written to third row.");
		System.out.println("This statement is written next to the previous one.");
		
	}
	
}
