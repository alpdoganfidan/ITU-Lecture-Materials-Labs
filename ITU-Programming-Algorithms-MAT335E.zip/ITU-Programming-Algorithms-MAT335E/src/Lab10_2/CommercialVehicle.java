package Lab10_2;

public interface CommercialVehicle {
	public double calculateAmortizedTax(double baseTax, int currentYear);
}
