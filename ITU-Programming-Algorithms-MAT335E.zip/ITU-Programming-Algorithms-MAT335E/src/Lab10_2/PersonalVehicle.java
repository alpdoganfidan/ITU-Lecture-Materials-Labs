package Lab10_2;

public interface PersonalVehicle {
	public double calculateTax(double baseTax);
}
